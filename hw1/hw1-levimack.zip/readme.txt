 - Levi Mack -
 - levi.mack@und.edu -

Command line argument used to execute this source code and get the following output:
./a.out date whoami ps du